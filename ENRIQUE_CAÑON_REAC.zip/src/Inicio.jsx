import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'


function App() {
  
    return(
      <>
        <br />
        <h3>Felicidades Ingresaste</h3>
        
      </>
    );
  }
         
    
    

export default App
